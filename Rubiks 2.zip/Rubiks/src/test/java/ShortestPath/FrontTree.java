package ShortestPath;
import solutioning.strategy.Action;
import rubikcube.RubikCube;
import rubikcube.RubikSide;
import rubikcube.RubikCube.FACE;

import java.util.*;

public class FrontTree {
    // Map to store the states of the Rubik's Cube and their respective levels
    public Map<RubikCube, Integer> frontSearchMap;
    // Map to store detailed Rubik's Cube states and their levels
    public Map<RubiksCubeState, Integer> stateMap;
    // Reference to the corresponding reverse tree in the bi-directional search
    public BackTree backTree;
    // Counter for the total number of nodes in the tree
    public int totalNodeCount;

    public FrontTree(BackTree backTree) {
        frontSearchMap = new HashMap<>();
        stateMap = new HashMap<>();
        this.backTree = backTree;
        totalNodeCount = 0;
        initializeStartingState();
    }

    private void initializeStartingState() {
        // Initialization of a Rubik's Cube with a specific sequence of moves
        RubikCube rubix = new RubikCube(3);
        try {
            rubix.turnRowToRight(0);
            rubix.turnRowToRight(1);
            rubix.turnColDown(0);
            rubix.turnRowToRight(2);
            rubix.turnRowToLeft(1);
            rubix.turnColDown(0);
            rubix.turnRowToRight(2);
            rubix.turnColDown(0);
            rubix.turnRowToRight(2);
            rubix.turnColUp(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        RubiksCubeState initialCubeState = new RubiksCubeState(rubix, 0, null);
        stateMap.put(initialCubeState, 1);
    }

    // Method to check if a solution is found in the reverse tree
    public boolean checkSolution(Map<RubiksCubeState, Integer> reverseTreeStates) {
        for (Map.Entry<RubiksCubeState, Integer> entry : stateMap.entrySet()) {
            RubiksCubeState frontNode = entry.getKey();
            Integer frontLevel = entry.getValue();

            if (reverseTreeStates.containsKey(frontNode)) {
                Integer reverseLevel = reverseTreeStates.get(frontNode);
                if (frontLevel.equals(reverseLevel)) {
                    System.out.println("Solution found at level: " + frontLevel);
                    return true;
                }
            }
        }
        return false;
    }

    // Method to generate more states for the front search tree
    public void generateMoreFrontStates() {
        Map<RubiksCubeState, Integer> currentLevelStates = new HashMap<>(stateMap);
        for (Map.Entry<RubiksCubeState, Integer> entry : currentLevelStates.entrySet()) {
            RubiksCubeState currentNode = entry.getKey();
            for (Action<RubikCube> action : currentNode.getRubiksCube().getAllActions()) {
                try {
                    RubikCube newState = currentNode.getRubiksCube().clone();
                    newState.performAction(action);
                    RubiksCubeState newStateNode = new RubiksCubeState(newState, currentNode.getLevel() + 1, currentNode);
                    if (!stateMap.containsKey(newStateNode)) {
                        stateMap.put(newStateNode, newStateNode.calculateMisplacedFacelets());
                        totalNodeCount++;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        if (checkSolution(backTree.getReverseSearchTree())) {
            System.out.println("Solution Found");
        } else {
            System.out.println("Expanding Reverse Search Tree");
            backTree.expandMoreStates();
        }
    }

    // Returns a list of all nodes in the front search tree
    public List<RubikCube> getAllFrontTreeNodes() {
        return new ArrayList<>(frontSearchMap.keySet());
    }

    // Returns the total number of nodes in the front search tree
    public int getTotalNodeCount() {
        return totalNodeCount;
    }

    // Other methods related to managing the front search tree nodes
    // ...
}




