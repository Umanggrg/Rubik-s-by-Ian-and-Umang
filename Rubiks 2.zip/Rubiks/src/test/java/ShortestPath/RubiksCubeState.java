package ShortestPath;
import rubikcube.RubikCube;
import java.util.List;
import java.util.Objects;

public class RubiksCubeState {
    private RubikCube rubiksCube;
    private int level;
    private RubiksCubeState parent;

    /**
     * Constructor for RubiksCubeState.
     * @param rubiksCube the current state of the Rubik's Cube.
     * @param level the depth or level in the search tree.
     * @param parent the parent state in the search tree.
     */
    public RubiksCubeState(RubikCube rubiksCube, int level, RubiksCubeState parent) {
        this.rubiksCube = rubiksCube;
        this.level = level;
        this.parent = parent;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof RubiksCubeState)) return false;
        RubiksCubeState other = (RubiksCubeState) o;
        // Equality is based on the cube's state
        return Objects.equals(this.rubiksCube.generateArray(), other.rubiksCube.generateArray());
    }

    @Override
    public int hashCode() {
        // Hash code based on the cube's state
        return Objects.hash(this.rubiksCube.generateArray());
    }

    /**
     * Gets the Rubik's Cube associated with this state.
     * @return the current Rubik's Cube.
     */
    public RubikCube getRubiksCube() {
        return rubiksCube;
    }

    /**
     * Gets the parent state in the search tree.
     * @return the parent RubiksCubeState.
     */
    public RubiksCubeState getParent() {
        return parent;
    }

    /**
     * Gets the level of this state in the search tree.
     * @return the level of the state.
     */
    public int getLevel() {
        return level;
    }

    /**
     * Calculates the number of misplaced facelets compared to the solved state.
     * @return the count of misplaced facelets.
     */
    public int calculateMisplacedFacelets() {
        int misplacedCount = 0;
        List<List<Integer>> currentState = this.rubiksCube.generateArray();
        RubikCube solved = new RubikCube(3);
        List<List<Integer>> solvedState = solved.generateArray();

        for (int i = 0; i < currentState.size(); i++) {
            for (int j = 0; j < currentState.get(i).size(); j++) {
                if (!currentState.get(i).get(j).equals(solvedState.get(i).get(j))) {
                    misplacedCount++;
                }
            }
        }
        return misplacedCount;
    }

    // Additional methods if needed
    // ...
}
