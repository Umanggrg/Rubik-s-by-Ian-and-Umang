package ShortestPath;
import rubikcube.RubikCube;
import rubikcube.RubikSide;


public class BackTreeTest {
    public static void main(String[] args) {
        // Define the limit for hash size or any other parameters if needed
        int limitHash = 5;

        // Record the start time
        long startTime = System.currentTimeMillis() / 1000;

        // Initialize the Reverse Search Tree
        BackTree backTest = new BackTree();

        // Output the number of nodes in the corresponding front tree
        System.out.println("Front tree nodes: " + backTest.correspondingFrontTree.getTotalNodeCount());

        // Output the number of nodes in the reverse search tree
        System.out.println("Reverse search tree nodes: " + backTest.getTotalNodeCount());

        // Calculate and output the duration of the operation
        long endTime = System.currentTimeMillis() / 1000;
        long duration = endTime - startTime;
        System.out.println("Operation duration (seconds): " + duration);
    }
}
