package ShortestPathTESTING;
import solutioning.strategy.Action;
import rubikcube.RubikCube;


import java.util.*;

public class FrontTree {
    public Map<RubikCube, Integer> frontTree; // Map storing the front tree states of the Rubik's Cube
    public Map<RubiksCubeState, Integer> ArrTree; // Map for detailed cube states with their corresponding search depth
    public BackTree backTree; // Reference to the corresponding back tree
    public int num_of_nodes; // Total number of nodes in the front tree
    public int limitBFS; // Limit for breadth-first search depth
    public int currentLevel; // Current depth level in the front tree

    // Constructor to initialize the front tree with a reference to the back tree
    public FrontTree(BackTree backTree) {
        this.limitBFS = backTree.limitBFS;
        this.frontTree = new HashMap<>();
        this.ArrTree = new HashMap<>();
        this.backTree = backTree;
        this.num_of_nodes = 0;

        // Initialize the Rubik's Cube to a scrambled state
        RubikCube rubix = new RubikCube(3);
        scrambleCube(rubix);

        // Create an initial state for the Rubik's Cube and add it to the tree
        RubiksCubeState initialState = new RubiksCubeState(rubix, 0, null);
        ArrTree.put(initialState, 1);
    }

    // Method to apply a series of moves to scramble the Rubik's Cube
    private void scrambleCube(RubikCube rubix) {
        try {
            //randomization
            rubix.turnRowToRight(0);
            rubix.turnRowToRight(1);
            rubix.turnColDown(0);
            rubix.turnRowToRight(2);
            rubix.turnRowToLeft(1);
            rubix.turnColDown(0);
            rubix.turnRowToRight(2);
            rubix.turnColDown(0);
            rubix.turnRowToRight(2);
            rubix.turnColUp(1);
        } catch (Exception e) {
            e.printStackTrace(); // Handle any exceptions during the scrambling process
        }
    }

    // Generate the front tree up to the specified BFS limit
    public void generate() {
        for (int i = 0; i < limitBFS; i++) {
            generateMoreFrontStates();
        }
    }

    // Method to check if a node from the back tree matches any nodes in the front tree
    public List<RubiksCubeState> getMatchingPath(RubiksCubeState backTreeNode) {
        Map<RubiksCubeState, Integer> frontTreeNodes = ArrTree;
        List<RubiksCubeState> path = new ArrayList<>();

        // Iterate through each node in the front tree to find a match
        for (Map.Entry<RubiksCubeState, Integer> frontEntry : frontTreeNodes.entrySet()) {
            RubiksCubeState frontNode = frontEntry.getKey();
            Integer frontCost = frontEntry.getValue();

            // Check if the node from the back tree matches a node in the front tree based on misplaced facelets
            if (frontCost.equals(backTreeNode.calculateMisplacedFacelets())) {
                if (Arrays.deepEquals(convertToArray(frontNode.getRubiksCube().generateArray()), convertToArray(backTreeNode.getRubiksCube().generateArray()))) {
                    return buildPathToFrontNode(frontNode); // Build and return the path if a match is found
                }
            }
        }
        currentLevel++;
        return path; // Return an empty list if no match is found
    }

    // Converts a List<List<Integer>> representation of a cube state to an array for comparison
    private Integer[][] convertToArray(List<List<Integer>> cubeState) {
        return cubeState.stream()
                .map(u -> u.toArray(new Integer[0]))
                .toArray(Integer[][]::new);
    }

    // Build the path from the given node to the root of the front tree
    private List<RubiksCubeState> buildPathToFrontNode(RubiksCubeState node) {
        List<RubiksCubeState> path = new ArrayList<>();
        while (node != null) {
            path.add(node);
            node = node.getParent();
        }
        Collections.reverse(path);
        return path;
    }

    // Generate the next level of states in the front tree
    public void generateMoreFrontStates() {
        System.out.println("Front Tree");
        Map<RubiksCubeState, Integer> frontTreeNodes = new HashMap<>(ArrTree);

        for (Map.Entry<RubiksCubeState, Integer> frontEntry : frontTreeNodes.entrySet()) {
            RubiksCubeState node = frontEntry.getKey();
            if (currentLevel == node.getLevel()) {
                processNodeActions(node);
            }
        }
        currentLevel++;
    }

    // Process all possible actions for a given node and update the tree
    private void processNodeActions(RubiksCubeState node) {
        for (Action<RubikCube> action : node.getRubiksCube().getAllActions()) {
            try {
                RubikCube newState = node.getRubiksCube().clone();
                newState.performAction(action);
                addNewStateToTree(node, newState);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    // Add a new state to the front tree if it's unique
    private void addNewStateToTree(RubiksCubeState parentNode, RubikCube newState) {
        RubiksCubeState newNode = new RubiksCubeState(newState, parentNode.getLevel() + 1, parentNode);
        if (!ArrTree.containsKey(newNode)) {
            ArrTree.put(newNode, newNode.calculateMisplacedFacelets());
            this.num_of_nodes++;
        }
    }

    // Get the total number of nodes in the front tree
    public int getNumNodes() {
        return this.num_of_nodes;
    }
}
