//
//*******//
// - By Ian and Umang
//*******//
// - We had a great amount of help from Calvin and especially Troy. Troy helped explain to
// - us how each of the classes communicates with each other and how to implement the
// - different algorithms.
//*******//


package ShortestPathTESTING;


public class main {
    public static void main(String[] args) {
        // Define the limits for hash depth and breadth-first search depth
        // These limits are used to control the depth of the search in the solution space
        int limitHash = 5;
        int limitBFS = 5;

        // Initialize the BackTree, which is responsible for solving the Rubik's Cube
        // The BackTree uses a combination of BFS and hash-based approaches to find the solution
        BackTree backTest = new BackTree(limitBFS, limitHash);

        // Start the parallel depth-first search traversal using the BackTree
        // The traversal starts from the solved node of the Rubik's Cube and explores backwards to find a solution path
        backTest.parallelDFSTraversal(backTest.solvedNode, limitHash + 1, 16);
    }
}

