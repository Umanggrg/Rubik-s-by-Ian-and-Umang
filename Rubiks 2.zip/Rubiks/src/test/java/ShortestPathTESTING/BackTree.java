package ShortestPathTESTING;
import solutioning.strategy.Action;
import rubikcube.RubikCube;


import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BackTree {
    private AtomicBoolean solutionFound = new AtomicBoolean(false); // Flag to indicate if a solution has been found
    public Map<RubikCube, Integer> backTree; // Map to store Rubik's Cube states and their levels
    public FrontTree frontTree; // Reference to the corresponding front tree
    public int num_of_nodes; // Total number of nodes in the back tree
    public Map<RubiksCubeState, Integer> ArrTree; // Map for detailed cube states with their corresponding levels
    public int limitBFS; // Limit for the depth of breadth-first search
    public int limitHash; // Limit for hashing depth
    public RubiksCubeState solvedNode; // Node representing the solved state of the Rubik's Cube
    public int currentLevel = 0; // Current level in the back tree
    private long timeA; // Time at which the algorithm started

    // Constructor to initialize the back tree with BFS and hash limits
    public BackTree(int limitBFS, int limitHash) {
        this.timeA = System.currentTimeMillis() / 1000;
        this.limitBFS = limitBFS;
        this.limitHash = limitHash;
        ArrTree = new HashMap<>();
        backTree = new HashMap<>();
        num_of_nodes = 0;
        frontTree = new FrontTree(this);

        // Create front and back trees in parallel threads to optimize initialization
        Thread frontTreeThread = new Thread(() -> frontTree.generate());
        Thread backTreeThread = new Thread(() -> generateInitialStates());
        frontTreeThread.start();
        backTreeThread.start();
        try {
            // Wait for both threads to complete execution
            frontTreeThread.join();
            backTreeThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    // Generate the initial states for the back tree
    public void generateInitialStates() {
        System.out.println("Back Tree");
        this.solvedNode = new RubiksCubeState(new RubikCube(3), 0, null);
        ArrTree.put(this.solvedNode, 0);

        // Iterate through all possible actions to generate initial states
        for (Action<RubikCube> action : solvedNode.getRubiksCube().getAllActions()) {
            try {
                RubikCube newState = solvedNode.getRubiksCube().clone();
                newState.performAction(action);
                RubiksCubeState newNode = new RubiksCubeState(newState, solvedNode.getLevel() + 1, solvedNode);
                ArrTree.put(newNode, 1);
                this.num_of_nodes++;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        currentLevel++;
        // Generate additional states based on the hash limit
        for (int i = 0; i < limitHash - 1; i++) {
            generateMoreStates();
        }
    }

    // Generate more states in the back tree as the search progresses
    public void generateMoreStates() {
        System.out.println("Expanding Back Tree Further");
        Map<RubiksCubeState, Integer> backTreeNodes = new HashMap<>(ArrTree);

        for (Map.Entry<RubiksCubeState, Integer> backEntry : backTreeNodes.entrySet()) {
            RubiksCubeState node = backEntry.getKey();

            if (currentLevel == node.getLevel()) {
                for (Action<RubikCube> action : node.getRubiksCube().getAllActions()) {
                    try {
                        RubikCube newState = node.getRubiksCube().clone();
                        newState.performAction(action);
                        RubiksCubeState newNode = new RubiksCubeState(newState, node.getLevel() + 1, node);
                        if (!ArrTree.containsKey(newNode)) {
                            ArrTree.put(newNode, newNode.calculateMisplacedFacelets());
                            this.num_of_nodes++;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        currentLevel++;
    }

    // Get the total number of nodes in the back tree
    public int getNumNodes() {
        return this.num_of_nodes;
    }

    // Perform a depth-first search (DFS) in the back tree
    public boolean DFS(RubiksCubeState currentNode, int depthLimit) {
        if (depthLimit <= 0) return false;

        if (frontTree.ArrTree.containsKey(currentNode)) {
            // If current node exists in the front tree, then a potential solution path is found
            List<RubiksCubeState> path = frontTree.getMatchingPath(currentNode);
            if (!path.isEmpty()) {
                // Build and print the solution path
                RubiksCubeState current = currentNode;
                while (current != null) {
                    path.add(current);
                    current = current.getParent();
                }
                path.forEach(step -> step.getRubiksCube().print());
                solutionFound.set(true);
                return true;
            }
        }

        // Recursively explore child nodes
        List<RubiksCubeState> children = currentNode.getChildren();
        for (RubiksCubeState child : children) {
            if (DFS(child, depthLimit - 1)) {
                solutionFound.set(true);
                return true;
            }
        }
        return false;
    }

    // Perform parallel DFS traversal to efficiently explore the solution space
    public void parallelDFSTraversal(RubiksCubeState root, int depthLimit, int numThreads) {
        ExecutorService executorService = Executors.newFixedThreadPool(numThreads);
        List<RubiksCubeState> rootChildren = getChildrenNodes(root);

        // Assign each subtree to a separate thread for concurrent exploration
        for (RubiksCubeState subRoot : rootChildren) {
            executorService.submit(() -> {
                if (DFS(subRoot, depthLimit - 1)) {
                    synchronized (solutionFound) {
                        solutionFound.set(true);
                    }
                    executorService.shutdownNow();
                    printInfo(this);
                    System.exit(0);
                }
            });
        }
        executorService.shutdown();
    }

    // Retrieve all children of a given Rubik's Cube state
    public List<RubiksCubeState> getChildrenNodes(RubiksCubeState rootNode) {
        List<RubiksCubeState> childrenNodes = new ArrayList<>(rootNode.getChildren());
        return childrenNodes;
    }

    // Print information about the search process and its outcome
    public void printInfo(BackTree backTest) {
        System.out.println("Front tree nodes: " + backTest.frontTree.getNumNodes());
        System.out.println("Back tree nodes: " + backTest.getNumNodes());

        long timeB = System.currentTimeMillis() / 1000;
        long totalTime = timeB - timeA;
        System.out.println("Time to complete: " + totalTime + " seconds");
    }
}
